-- MySQL dump 10.13  Distrib 8.0.29, for Win64 (x86_64)
--
-- Host: localhost    Database: employee_management
-- ------------------------------------------------------
-- Server version	8.0.29

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `emp_info`
--

DROP TABLE IF EXISTS `emp_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `emp_info` (
  `emp_id` int NOT NULL AUTO_INCREMENT,
  `department` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `gender` enum('Male','Female','Other') NOT NULL,
  `location` varchar(45) NOT NULL,
  PRIMARY KEY (`emp_id`),
  UNIQUE KEY `email_UNIQUE` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `emp_info`
--

LOCK TABLES `emp_info` WRITE;
/*!40000 ALTER TABLE `emp_info` DISABLE KEYS */;
INSERT INTO `emp_info` VALUES (1,'HR','revati@amdocs.com','9284352678','Female','Pune'),(2,'Software Development','anshika@amdocs.com','8434005429','Female','Mumbai'),(3,'Quality Assurance','tanvi@amdocs.com','7030655683','Female','Pune'),(4,'Technical Support','naina@amdocs.com','9356686725','Female','Bangalore'),(5,'DevOps\n','swamini@amdocs.com','9028541519','Female','Hyderabad'),(6,'HR','akshay@amdocs.com','8956440066','Male','Pune'),(7,'Software Development','sanya@amdocs.com','8856687825','Female','Mumbai'),(8,'Quality Assurance','prateek@amdocs.com','9956086779','Male','Mumbai'),(9,'Cybersecurity','raj@amdocs.com','9344486435','Male','Hyderabad'),(10,'IT Helpdesk','amey@amdocs.com','8977686700','Male','Bangalore'),(11,'HR','vaishnavi@amdocs.com','7782351920','Female','Pune'),(12,'Technical Support','soham@amdocs.com','8829351628','Male','Bangalore'),(13,'Database Administration','sonali@amdocs.com','9812346536','Female','Hyderabad'),(14,'Software Development','nilesh@amdocs.com','7263547283','Male','Pune'),(15,'Software Development','neha@amdocs.com','8274629103','Female','Bangalore'),(16,'HR','anand@amdocs.com','9283929374','Male','Mumbai'),(17,'DevOps\n','pranav@amdocs.com','8293746322','Male','Hyderabad'),(18,'Cybersecurity','reshma@amdocs.com','9820837472','Female','Bangalore'),(19,'HR','tanaya@amdocs.com','8927635377','Female','Hyderabad'),(20,'Database Administration','sujay@amdocs.com','9287372999','Male','Bangalore');
/*!40000 ALTER TABLE `emp_info` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-08-25 15:45:23
