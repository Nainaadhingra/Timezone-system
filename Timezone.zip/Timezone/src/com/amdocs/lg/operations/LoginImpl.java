package com.amdocs.lg.operations;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.amdocs.lg.bean.Login;
import com.amdocs.lg.interfaces.LoginIntf;

public class LoginImpl implements LoginIntf {
	 private static final String URL = "jdbc:mysql://localhost:3306/db8";
	 private static final String USER = "root"; // Replace with your MySQL username
	 private static final String PASSWORD = "root"; // Replace with your MySQL password
	
	@Override
	public boolean verify(Login login) {
	        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD)) {
	            String sql = "SELECT * FROM users WHERE emp_id = ? AND password = ?";
	            PreparedStatement statement = connection.prepareStatement(sql);
	            statement.setString(1, login.getEmp_id());
	            statement.setString(2, login.getPassword());

	            ResultSet resultSet = statement.executeQuery();
	            return resultSet.next(); 

	        } catch (Exception e) {
	            e.printStackTrace();
	            return false;
	        }
	    }
	}

