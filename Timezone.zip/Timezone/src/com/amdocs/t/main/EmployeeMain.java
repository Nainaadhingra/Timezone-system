package com.amdocs.t.main;

/*import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.sql.*;*/
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Scanner;

import com.amdocs.et.bean.EmployeeTimezoneHours;
import com.amdocs.et.bean.EmployeeTimezoneLeaves;
import com.amdocs.et.operations.EmployeeTimezoneHoursImpl;
import com.amdocs.et.operations.EmployeeTimezoneLeavesImpl;

public class EmployeeMain {

	public static void main(String[] args) {
		String punch_in;
		String punch_out;
		String dateInput;
		int leave_taken;
		int choice;
		int repeat = 1;

		EmployeeTimezoneLeaves employeeTimezone = new EmployeeTimezoneLeaves();
		EmployeeTimezoneLeavesImpl employeeTimezoneLeavesImpl = new EmployeeTimezoneLeavesImpl(employeeTimezone);

		LinkedHashSet<String> workingHoursLog = new LinkedHashSet<>();
		Scanner scanner = new Scanner(System.in);

		while (repeat == 1) {

			System.out.println("1. Update Timezone ");
			System.out.println("2. Update Leaves ");
			System.out.println("3. Exit ");
			System.out.println("Enter your choice (1-3): ");
			choice = scanner.nextInt();

			switch (choice) {
			case 1: {
				System.out.print("Enter the date (yyyy-MM-dd): ");
				dateInput = scanner.next();
				LocalDate date = null;
				try {
					date = LocalDate.parse(dateInput, DateTimeFormatter.ISO_LOCAL_DATE);
				} catch (DateTimeParseException e) {
					System.out.println("Invalid date format. Please use yyyy-MM-dd format.");
					break;
				}
				final LocalDate finalDate = date;

				System.out.print("Enter punch in time (HH:mm): ");
				punch_in = scanner.next();
				System.out.print("Enter punch out time (HH:mm): ");
				punch_out = scanner.next();

				EmployeeTimezoneHours employeeTimezoneHours = new EmployeeTimezoneHours(punch_in, punch_out);
				EmployeeTimezoneHoursImpl employeeTimezoneHoursImpl = new EmployeeTimezoneHoursImpl();
				long hoursWorked = employeeTimezoneHoursImpl.calculateTotalHoursWorked(employeeTimezoneHours);
				System.out.println("Total hours worked: " + hoursWorked + " hours");

				String logEntry = date.toString() + ": " + hoursWorked + " hours worked";

				boolean entryExists = workingHoursLog.stream()
						.anyMatch(entry -> entry.startsWith(finalDate.toString()));

				if (!entryExists) {
					workingHoursLog.add(logEntry);
					System.out.println("Log Entry Added: " + logEntry);
				} else {
					System.out.println("An entry for this date already exists.");
				}
				Iterator<String> itr = workingHoursLog.iterator();
				while (itr.hasNext()) {
					System.out.println(itr.next().toString());
				}
				break;
			}
			case 2: {
				System.out.print("Leaves Requested: ");
				leave_taken = scanner.nextInt();
				int leave_available = employeeTimezoneLeavesImpl.totalLeaves(leave_taken);
				System.out.println("Leaves Available: " + leave_available);
				break;
			}
			case 3: {
				System.exit(0);
				break;
			}
			default: {
				System.out.println("Out of range, Try again !!! ");
			}
			}

			System.out.println("\nDo you want to continue (0/1)?");
			repeat = scanner.nextInt();
		}
		scanner.close();
	}
}
