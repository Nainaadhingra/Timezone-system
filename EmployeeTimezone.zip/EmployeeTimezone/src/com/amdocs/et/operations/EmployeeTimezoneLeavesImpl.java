package com.amdocs.et.operations;

//import java.sql.Connection;
//import java.sql.DriverManager;
//import java.sql.PreparedStatement;
//import java.sql.ResultSet;
//import java.sql.SQLException;

import com.amdocs.et.bean.EmployeeTimezoneLeaves;
import com.amdocs.et.interfaces.EmployeeTimezoneLeavesIntf;

public class EmployeeTimezoneLeavesImpl implements EmployeeTimezoneLeavesIntf {

	private EmployeeTimezoneLeaves employeeTimezone;
/*	private Connection connection;

    public EmployeeTimezoneLeavesImpl() {
        try {
            // Connect to the database
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/employee_management", "root", "root"); // Update URL, username, and password
        } catch (SQLException e) {
            e.printStackTrace();
            System.exit(1);
        }
    }

	public EmployeeTimezoneLeavesImpl(EmployeeTimezoneLeaves employeeTimezone) {
		this.employeeTimezone = employeeTimezone;
	}
	@Override
    public void updateEmployeeDetails(int emp_id, int leave_taken, int leave_available) {
        String sql = "UPDATE emp_info SET punch_in = ?, punch_out = ? WHERE emp_id = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, leave_taken);
            statement.setInt(2, leave_available);
            statement.setInt(3, emp_id);
            int rowsUpdated = statement.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Employee details updated successfully.");
            } else {
                System.out.println("Employee with ID " + emp_id + " does not exist.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
	@Override
    public void viewAllEmployees() throws SQLException {
        String sql = "SELECT * FROM emp_info";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            ResultSet resultSet = statement.executeQuery();
            if (!resultSet.isBeforeFirst()) {
                System.out.println("No records found.");
            } else {
                System.out.println("Employee Timezone Records:");
                while (resultSet.next()) {
                	int emp_id = resultSet.getInt("emp_id");
                	int leave_taken = resultSet.getInt("leave_taken");
                	int leave_available = resultSet.getInt("leave_available");
                    System.out.println("ID: " + emp_id + ", leave_taken: " + leave_taken + ", leave_available: " + leave_available);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw e;
        }
    } */
	public EmployeeTimezoneLeavesImpl(EmployeeTimezoneLeaves employeeTimezone) {
		this.employeeTimezone = employeeTimezone;
	}
	@Override
	public int totalLeaves(int leave_taken) {
		employeeTimezone.addLeave_taken(leave_taken);
		return employeeTimezone.getLeaves_available();
	}
}