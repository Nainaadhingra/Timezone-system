package com.amdocs.et.operations;

import com.amdocs.et.interfaces.EmployeeTimezoneLeavesIntf;

import java.sql.*;

public class EmployeeTimezoneLeavesImpl implements EmployeeTimezoneLeavesIntf {

    private static final String DB_URL = "jdbc:mysql://localhost:3306/employee_management";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "root";

    @Override
    public boolean checkEmployeeIdExists(String empId) throws SQLException {
        try (Connection con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            String query = "SELECT COUNT(*) FROM emp_holidays WHERE emp_id = ?";
            try (PreparedStatement ps = con.prepareStatement(query)) {
                ps.setString(1, empId);
                ResultSet rs = ps.executeQuery();
                if (rs.next()) {
                    return rs.getInt(1) > 0;
                }
                return false; // Employee ID not found
            }
        }
    }

    @Override
    public int getCurrentLeaveBalance(String empId) throws SQLException {
        try (Connection con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            String query = "SELECT leave_available FROM emp_holidays WHERE emp_id = ?";
            try (PreparedStatement ps = con.prepareStatement(query)) {
                ps.setString(1, empId);
                ResultSet rs = ps.executeQuery();
                if (rs.next()) {
                    return rs.getInt("leave_available");
                }
                return -1; // Employee ID not found or other error
            }
        }
    }

    @Override
    public void updateLeaveRecords(String empId, int leaveRequested) throws SQLException {
        if (checkEmployeeIdExists(empId)) {
            int currentLeaveBalance = getCurrentLeaveBalance(empId);
            if (currentLeaveBalance >= leaveRequested) {
                try (Connection con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
                    con.setAutoCommit(false);

                    String updateQuery = "UPDATE emp_holidays SET leave_taken = leave_taken + ?, leave_available = leave_available - ? WHERE emp_id = ?";
                    try (PreparedStatement ps = con.prepareStatement(updateQuery)) {
                        ps.setInt(1, leaveRequested);
                        ps.setInt(2, leaveRequested);
                        ps.setString(3, empId);
                        ps.executeUpdate();
                    }

                    con.commit();
                    System.out.println("Leave records updated successfully.");
                }
            } else {
                System.out.println("Not enough leave balance.");
            }
        } else {
            System.out.println("Employee ID not found.");
        }
    }
}
