package com.amdocs.et.operations;

import com.amdocs.et.bean.EmployeeTimezoneLeaves;
import com.amdocs.et.interfaces.EmployeeTimezoneLeavesIntf;

public class EmployeeTimezoneLeavesImpl implements EmployeeTimezoneLeavesIntf {

	private EmployeeTimezoneLeaves employeeTimezone;

	public EmployeeTimezoneLeavesImpl(EmployeeTimezoneLeaves employeeTimezone) {
		this.employeeTimezone = employeeTimezone;
	}

	@Override
	public int totalLeaves(int leave_taken) {
		employeeTimezone.addLeave_taken(leave_taken);
		return employeeTimezone.getLeaves_available();
	}
}