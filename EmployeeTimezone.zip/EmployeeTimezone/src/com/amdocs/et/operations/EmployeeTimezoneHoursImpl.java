package com.amdocs.et.operations;

//import java.sql.Connection;
//import java.sql.DriverManager;
//import java.sql.PreparedStatement;
//import java.sql.ResultSet;
//import java.sql.SQLException;
import java.time.Duration;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

import com.amdocs.et.bean.EmployeeTimezoneHours;
import com.amdocs.et.interfaces.EmployeeTimezoneHoursIntf;

public class EmployeeTimezoneHoursImpl implements EmployeeTimezoneHoursIntf {

	/* private Connection connection;

    public EmployeeTimezoneHoursImpl() {
        try {
            // Connect to the database
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/employee_management", "root", "root"); // Update URL, username, and password
        } catch (SQLException e) {
            e.printStackTrace();
            System.exit(1);
        }
    }
    @Override
    public void updateEmployeeDetails(int emp_id, String punch_in, String punch_out) {
        String sql = "UPDATE emp_info SET punch_in = ?, punch_out = ? WHERE emp_id = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, punch_in);
            statement.setString(2, punch_out);
            statement.setInt(3, emp_id);
            int rowsUpdated = statement.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Employee details updated successfully.");
            } else {
                System.out.println("Employee with ID " + emp_id + " does not exist.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    @Override
    public void viewAllEmployees() throws SQLException {
        String sql = "SELECT * FROM emp_info";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            ResultSet resultSet = statement.executeQuery();
            if (!resultSet.isBeforeFirst()) {
                System.out.println("No records found.");
            } else {
                System.out.println("Employee Timezone Records:");
                while (resultSet.next()) {
                    int emp_id = resultSet.getInt("emp_id");
                    String punch_in = resultSet.getString("punch_in");
                    String punch_out = resultSet.getString("punch_out");
                    System.out.println("ID: " + emp_id + ", punch_in: " + punch_in + ", punch_out: " + punch_out);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw e;
        }
    } */
	
	@Override
	public LocalTime convertTo24HourFormat(String timeString) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm");
		try {
			return LocalTime.parse(timeString, formatter);
		} catch (DateTimeParseException e) {
			System.out.println("Invalid time format. Please use HH:mm format.");
			return null;
		}
	}

	// Method to find the time difference between two LocalTime objects
	@Override
	public long calculateTotalHoursWorked(EmployeeTimezoneHours employeeTimezoneHours) {

		LocalTime punch_in = convertTo24HourFormat(employeeTimezoneHours.getPunch_in());
		LocalTime punch_out = convertTo24HourFormat(employeeTimezoneHours.getPunch_out());

		if (punch_in != null && punch_out != null) {
			Duration duration = Duration.between(punch_in, punch_out);
			return duration.toHours(); // Return the difference in hours
		} else {
			System.out.println("Unable to calculate total hours due to invalid time format.");
			return 0;
		}
	}

}
