package com.amdocs.et.operations;

import com.amdocs.et.bean.EmployeeTimezoneHours;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

public class EmployeeTimezoneHoursImpl {

	private static final String DB_URL = "jdbc:mysql://localhost:3306/employee_management";
	private static final String DB_USER = "root";
	private static final String DB_PASSWORD = "root";
	private static final DateTimeFormatter DATE_TIME_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

	public void updateEmployeeTimesheet(String empId, EmployeeTimezoneHours employeeTimezoneHours) {
		String dateInput = employeeTimezoneHours.getDate();
		String punchInTime = employeeTimezoneHours.getPunch_in();
		String punchOutTime = employeeTimezoneHours.getPunch_out();

		// Combine date with punch-in and punch-out times
		String punchInDateTime = dateInput + " " + punchInTime + ":00";
		String punchOutDateTime = dateInput + " " + punchOutTime + ":00";

		try {
			// Parse the date-time strings
			LocalDateTime punchIn = LocalDateTime.parse(punchInDateTime, DATE_TIME_FORMATTER);
			LocalDateTime punchOut = LocalDateTime.parse(punchOutDateTime, DATE_TIME_FORMATTER);

			// Calculate hours worked
			long hoursWorked = Duration.between(punchIn, punchOut).toHours();

			try (Connection con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
				// Check if record exists
				String checkQuery = "SELECT COUNT(*) FROM emp_timesheet WHERE emp_id = ? AND punch_in = ?";
				try (PreparedStatement psCheck = con.prepareStatement(checkQuery)) {
					psCheck.setString(1, empId);
					psCheck.setString(2, punchInDateTime);
					ResultSet rsCheck = psCheck.executeQuery();
					rsCheck.next();
					if (rsCheck.getInt(1) > 0) {
						// Update existing record
						String updateQuery = "UPDATE emp_timesheet SET punch_out = ? WHERE emp_id = ? AND punch_in = ?";
						try (PreparedStatement psUpdate = con.prepareStatement(updateQuery)) {
							psUpdate.setString(1, punchOutDateTime);
							psUpdate.setString(2, empId);
							psUpdate.setString(3, punchInDateTime);
							psUpdate.executeUpdate();
							System.out.println("Record updated successfully.");
						}
					} else {
						// Insert new record
						String insertQuery = "INSERT INTO emp_timesheet (emp_id, punch_in, punch_out) VALUES (?, ?, ?)";
						try (PreparedStatement psInsert = con.prepareStatement(insertQuery)) {
							psInsert.setString(1, empId);
							psInsert.setString(2, punchInDateTime);
							psInsert.setString(3, punchOutDateTime);
							psInsert.executeUpdate();
							System.out.println("Record inserted successfully.");
						}
					}
				}
			} catch (SQLException e) {
				System.out.println("Database error occurred.");
				e.printStackTrace();
			}
		} catch (DateTimeParseException e) {
			System.out.println("Invalid date-time format. Please use yyyy-MM-dd for date and HH:mm for time.");
			e.printStackTrace();
		}
	}
}
