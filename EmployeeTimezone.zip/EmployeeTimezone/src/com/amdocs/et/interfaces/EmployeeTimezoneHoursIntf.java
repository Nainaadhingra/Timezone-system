package com.amdocs.et.interfaces;

import java.time.LocalTime;

import com.amdocs.et.bean.EmployeeTimezoneHours;

public interface EmployeeTimezoneHoursIntf {
	long calculateTotalHoursWorked(EmployeeTimezoneHours employeeTimezoneHours);

	LocalTime convertTo24HourFormat(String timeString);
}
