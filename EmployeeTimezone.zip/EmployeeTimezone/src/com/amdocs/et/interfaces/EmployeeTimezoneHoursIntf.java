package com.amdocs.et.interfaces;

//import java.sql.SQLException;
import java.time.LocalTime;

import com.amdocs.et.bean.EmployeeTimezoneHours;

public interface EmployeeTimezoneHoursIntf {
//	void updateEmployeeDetails(int emp_id, String punch_in, String punch_out);
//	void viewAllEmployees() throws SQLException;
	long calculateTotalHoursWorked(EmployeeTimezoneHours employeeTimezoneHours);
	LocalTime convertTo24HourFormat(String timeString);
}
