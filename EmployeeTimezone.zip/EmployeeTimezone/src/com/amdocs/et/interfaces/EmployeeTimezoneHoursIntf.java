package com.amdocs.et.interfaces;

import com.amdocs.et.bean.EmployeeTimezoneHours;
import java.sql.SQLException;

public interface EmployeeTimezoneHoursIntf {

    /**
     * Calculate the total hours worked based on punch_in and punch_out times.
     * @param employeeTimezoneHours The object containing punch_in and punch_out times.
     * @return The total hours worked.
     */
    long calculateTotalHoursWorked(EmployeeTimezoneHours employeeTimezoneHours);

    /**
     * Update the employee's time sheet in the database.
     * @param empId The employee's ID.
     * @param employeeTimezoneHours The object containing punch_in and punch_out times.
     * @throws SQLException If there is an error updating the database.
     */
    void updateEmployeeTimesheet(String empId, EmployeeTimezoneHours employeeTimezoneHours) throws SQLException;
}
