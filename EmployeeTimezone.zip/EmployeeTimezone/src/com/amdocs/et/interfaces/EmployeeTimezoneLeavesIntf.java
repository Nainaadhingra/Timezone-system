package com.amdocs.et.interfaces;

import java.sql.SQLException;

public interface EmployeeTimezoneLeavesIntf {
    boolean checkEmployeeIdExists(String empId) throws SQLException;
    int getCurrentLeaveBalance(String empId) throws SQLException;
    void updateLeaveRecords(String empId, int leaveRequested) throws SQLException;
}
