package com.amdocs.et.interfaces;

//import java.sql.SQLException;

public interface EmployeeTimezoneLeavesIntf {
//	void updateEmployeeDetails(int emp_id, int leave_taken, int leave_available);
//	void viewAllEmployees() throws SQLException;
	int totalLeaves(int leave_taken);
}
