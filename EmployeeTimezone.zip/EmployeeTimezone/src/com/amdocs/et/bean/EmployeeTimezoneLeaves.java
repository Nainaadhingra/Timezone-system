package com.amdocs.et.bean;

public class EmployeeTimezoneLeaves {
	private static final int TOTAL_LEAVES = 10; // Total leaves remains constant
	private int leave_taken;

	public EmployeeTimezoneLeaves() {
		this.leave_taken = 0; // Initialize with 0 applied leaves
	}

	public int getLeave_taken() {
		return leave_taken;
	}

	public void addLeave_taken(int leave_taken) {
		this.leave_taken += leave_taken; // Accumulate leaves applied
	}

	public int getLeaves_available() {
		return TOTAL_LEAVES - leave_taken;
	}
}
