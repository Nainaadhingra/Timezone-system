package com.amdocs.et.main;

import com.amdocs.et.bean.EmployeeTimezoneHours;
import com.amdocs.et.operations.EmployeeTimezoneHoursImpl;
import com.amdocs.et.operations.EmployeeTimezoneLeavesImpl;

import java.sql.SQLException;
import java.util.InputMismatchException;
import java.util.Scanner;

public class EmployeeTimezoneMain {
    private static final Scanner scanner = new Scanner(System.in);
    private static final EmployeeTimezoneHoursImpl employeeTimezoneHoursImpl = new EmployeeTimezoneHoursImpl();
    private static final EmployeeTimezoneLeavesImpl employeeTimezoneLeavesImpl = new EmployeeTimezoneLeavesImpl();

    public static void main(String[] args) {
        // This main method is meant to be invoked from TimezoneMain only
    }

    public static void showEmployeeMenu(String empId) {
        int choice;
        do {
            showMenu();
            choice = getUserChoice();

            switch (choice) {
                case 1:
                    updateTimesheet(empId);
                    break;
                case 2:
                    updateLeaves(empId);
                    break;
                case 3:
                    System.out.println("Returning to the main menu...");
                    showMenu(); // Exits the employee menu and returns to the main menu
                    break;
                case 4:
                    System.out.println("Logged out");
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid choice. Please select a valid option.");
                    break;
            }
        } while (choice != 4);
    }

    private static void showMenu() {
        System.out.println("\nEmployee Time Management System");
        System.out.println("1. Update Timesheet");
        System.out.println("2. Update Leaves");
        System.out.println("3. Go to Main Menu");
        System.out.println("4. Logout");
    }

    private static int getUserChoice() {
        int choice = 0;
        boolean valid = false;

        while (!valid) {
            try {
                System.out.print("Please select an option (1-4): ");
                choice = scanner.nextInt();
                scanner.nextLine(); // Consume newline
                valid = (choice >= 1 && choice <= 4);
                if (!valid) {
                    System.out.println("Invalid option. Please select a number between 1 and 4:");
                }
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter a number between 1 and 4:");
                scanner.next(); // Clear the invalid input
            }
        }
        return choice;
    }

    private static void updateTimesheet(String empId) {
        try {
            System.out.print("Enter Date (yyyy-MM-dd): ");
            String date = scanner.nextLine();

            System.out.print("Enter Punch In Time (HH:mm): ");
            String punchIn = scanner.nextLine();

            System.out.print("Enter Punch Out Time (HH:mm): ");
            String punchOut = scanner.nextLine();

            EmployeeTimezoneHours employeeTimezoneHours = new EmployeeTimezoneHours(date, punchIn, punchOut);
            employeeTimezoneHoursImpl.updateEmployeeTimesheet(empId, employeeTimezoneHours);
        } catch (Exception e) {
            System.out.println("Error occurred while updating timesheet.");
            e.printStackTrace();
        }
    }

    private static void updateLeaves(String empId) {
        try {
            System.out.print("Enter Number of Leave Days Requested: ");
            int leaveRequested = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            // Display current leave balance and update records
            int currentLeaveBalance = employeeTimezoneLeavesImpl.getCurrentLeaveBalance(empId);
            if (currentLeaveBalance >= 0) {
                System.out.println("Current leave balance: " + currentLeaveBalance);
                employeeTimezoneLeavesImpl.updateLeaveRecords(empId, leaveRequested);
            } else {
                System.out.println("Error retrieving leave balance.");
            }
        } catch (SQLException e) {
            System.out.println("Error occurred while updating leave records.");
            e.printStackTrace();
        }
    }
}
