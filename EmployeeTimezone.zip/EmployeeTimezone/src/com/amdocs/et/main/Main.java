package com.amdocs.et.main;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.sql.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Scanner;

import com.amdocs.et.bean.EmployeeTimezoneHours;
import com.amdocs.et.bean.EmployeeTimezoneLeaves;
import com.amdocs.et.operations.EmployeeTimezoneHoursImpl;
import com.amdocs.et.operations.EmployeeTimezoneLeavesImpl;

public class Main {

	public static void main(String[] args) {
		String punch_in;
		String punch_out;
		String dateInput;
		int leave_taken;
		int choice;
		int repeat = 1;
		String emp_id = null;
		String password = null;
		
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

		EmployeeTimezoneLeaves employeeTimezone = new EmployeeTimezoneLeaves();
		EmployeeTimezoneLeavesImpl employeeTimezoneLeavesImpl = new EmployeeTimezoneLeavesImpl(employeeTimezone);
		EmployeeTimezoneHoursImpl employeeTimezoneHoursImpl = new EmployeeTimezoneHoursImpl();
		
		LinkedHashSet<String> workingHoursLog = new LinkedHashSet<>(); // To store working hours with dates
		Scanner scanner = new Scanner(System.in);


		while (repeat == 1) {

			System.out.println("1. Update Timezone ");
			System.out.println("2. Update Leaves ");
			System.out.println("3. Exit ");
			System.out.println("Enter your choice (1-3): ");
			choice = scanner.nextInt();

			switch (choice) {
			case 1: {
				// Accept the date from the user
				System.out.print("Enter the date (yyyy-MM-dd): ");
				dateInput = scanner.next();
				LocalDate date = null;

				// Validate the date input
				try {
					date = LocalDate.parse(dateInput, DateTimeFormatter.ISO_LOCAL_DATE);
				} catch (DateTimeParseException e) {
					System.out.println("Invalid date format. Please use yyyy-MM-dd format.");
					break;
				}
				final LocalDate finalDate = date;

				System.out.print("Enter punch in time (HH:mm): ");
				punch_in = scanner.next();

				System.out.print("Enter punch out time (HH:mm): ");
				punch_out = scanner.next();

				// Create an EmployeeTimezoneHours object with the provided times
				EmployeeTimezoneHours employeeTimezoneHours = new EmployeeTimezoneHours(punch_in, punch_out);

				// Calculate the total hours worked
				long hoursWorked = employeeTimezoneHoursImpl.calculateTotalHoursWorked(employeeTimezoneHours);
				System.out.println("Total hours worked: " + hoursWorked + " hours");

				String logEntry = date.toString() + ": " + hoursWorked + " hours worked";

				// Check if an entry for the specified date already exists
				boolean entryExists = workingHoursLog.stream()
						.anyMatch(entry -> entry.startsWith(finalDate.toString()));

				if (!entryExists) {
					workingHoursLog.add(logEntry);
					System.out.println("Log Entry Added: " + logEntry);
				} else {
					System.out.println("An entry for this date already exists.");
				}
				Iterator<String> itr = workingHoursLog.iterator();
				while (itr.hasNext()) {
					System.out.println(itr.next().toString());
				}
//				System.out.println("Enter emp_id and passsword");
				try {
//					emp_id = br.readLine();
//					password = br.readLine();
					Class.forName("com.mysql.cj.jdbc.Driver");
					//Connection con = DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:XE", "system", "AkhilesH123");
					Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/db2", "root", "root");
					Statement st = con.createStatement();

					int result = st.executeUpdate("Insert into emp values('" + emp_id + "','" + punch_in +  "','" + punch_out + "')");
					System.out.println("record inserted sucessfully");
					ResultSet rs = st.executeQuery("select * from emp");

//					JOptionPane.showMessageDialog(null,"record inserted successfully");
					System.out.println("Records are :");
					while (rs.next()) {
						System.out.println((rs.getString(1) + "  " + rs.getString(2)));
					}

				} catch (Exception e) {
					System.out.println("Sorry Connection Is Not Available" + e);
				}
				break;
			}
			case 2: {	
				System.out.print("Leaves Requested: ");
				leave_taken = scanner.nextInt();
				int leave_available = employeeTimezoneLeavesImpl.totalLeaves(leave_taken);
				System.out.println("Leaves Available: " + leave_available);
//				System.out.println("Enter emp_id and passsword");
				try {
//					emp_id = br.readLine();
//					password = br.readLine();
					Class.forName("com.mysql.cj.jdbc.Driver");
					//Connection con = DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:XE", "system", "AkhilesH123");
					Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/employee_management", "root", "root");
					Statement st = con.createStatement();

					int result = st.executeUpdate("Insert into emp values('" + emp_id + "','" + leave_taken +  "','" + leave_available + "')");
					System.out.println("record inserted sucessfully");
					ResultSet rs = st.executeQuery("select * from emp");

//					JOptionPane.showMessageDialog(null,"record inserted successfully");
					System.out.println("Records are :");
					while (rs.next()) {
						System.out.println((rs.getString(1) + "  " + rs.getString(2)));
					}

				} catch (Exception e) {
					System.out.println("Sorry Connection Is Not Available" + e);
				}
				break;
			}
			case 3: {
				System.exit(0);
				break;
			}
			default: {
				System.out.println("Out of range, Try again !!! ");
			}
			}

			System.out.println("\nDo you want to continue (0/1)?");
			repeat = scanner.nextInt();
		}
		scanner.close();
	}
}
