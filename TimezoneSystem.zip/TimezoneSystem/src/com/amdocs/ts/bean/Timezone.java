package com.amdocs.ts.bean;

public class Timezone {
	private int emp_Id;
	private String password;

	public Timezone() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Timezone(int emp_Id, String password) {
		super();
		this.emp_Id = emp_Id;
		this.password = password;
	}

	

	@Override
	public String toString() {
		return "Timezone [emp_Id=" + emp_Id + ", password=" + password + "]";
	}

	public int getEmp_Id() {
		return emp_Id;
	}

	public void setEmp_Id(int emp_Id) {
		this.emp_Id = emp_Id;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

}
