package com.amdocs.ts.main;

import com.amdocs.lg.bean.Login;
import com.amdocs.lg.operations.LoginImpl;
import com.amdocs.et.main.EmployeeTimezoneMain;
import com.amdocs.ht.main.HrTimezoneMain;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class TimezoneMain {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        LoginImpl loginImpl = new LoginImpl(); // Instance of LoginImpl to verify login

        System.out.println("Enter the choice for Login:");
        System.out.println("1. HR");
        System.out.println("2. Employee");
        int choice = sc.nextInt();
        sc.nextLine(); // Consume newline

        switch (choice) {
            case 1:
                handleHrLogin(sc, loginImpl);
                break;

            case 2:
                handleEmployeeLogin(sc, loginImpl);
                break;

            default:
                System.out.println("Invalid choice. Please select 1 or 2.");
                break;
        }

        sc.close();
    }

    private static void handleHrLogin(Scanner sc, LoginImpl loginImpl) {
        try {
            System.out.print("Enter employee id: ");
            String empId = sc.nextLine();

            System.out.print("Enter password: ");
            String password = sc.nextLine();

            // Verify login credentials first
            Login login = new Login(empId, password);

            if (loginImpl.verify(login) && isHrEmployee(empId)) {
                System.out.println("Login successful! Welcome HR.");
                HrTimezoneMain.main(new String[0]); // Start HR functionality
            } else {
                System.out.println("Access denied. Either invalid credentials or you are not an HR employee.");
            }
        } catch (SQLException e) {
            System.out.println("Database error occurred.");
            e.printStackTrace();
        }
    }

    private static boolean isHrEmployee(String empId) throws SQLException {
        boolean isHr = false;
        String url = "jdbc:mysql://localhost:3306/employee_management";
        String user = "root";
        String password = "root";

        try (Connection con = DriverManager.getConnection(url, user, password);
             PreparedStatement pst = con.prepareStatement("SELECT department FROM emp_info WHERE emp_id = ?")) {
            pst.setString(1, empId);
            try (ResultSet rs = pst.executeQuery()) {
                if (rs.next()) {
                    String department = rs.getString("department");
                    isHr = "HR".equalsIgnoreCase(department);
                }
            }
        }
        return isHr;
    }

    private static void handleEmployeeLogin(Scanner sc, LoginImpl loginImpl) {
        try {
            System.out.print("Enter employee id: ");
            String empId = sc.nextLine();

            System.out.print("Enter password: ");
            String password = sc.nextLine();

            Login login = new Login(empId, password);

            if (loginImpl.verify(login)) {
                System.out.println("Login successful! Welcome.");
                EmployeeTimezoneMain.showEmployeeMenu(empId); // Show employee-specific menu
            } else {
                System.out.println("Login failed. Invalid username or password.");
            }
        } catch (SQLException e) {
            System.out.println("Database error occurred.");
            e.printStackTrace();
        }
    }
}
