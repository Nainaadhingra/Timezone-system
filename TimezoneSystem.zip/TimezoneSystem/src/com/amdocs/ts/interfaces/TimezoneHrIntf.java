package com.amdocs.ts.interfaces;

public class TimezoneHrIntf {
	
}
