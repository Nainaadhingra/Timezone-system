package com.amdocs.ht.interfaces;

import java.sql.SQLException;

import com.amdocs.ht.bean.HrTimezone;

public interface HrTimezoneIntf {
	void registerEmployee(HrTimezone hrtimezone) throws SQLException;

	void updateEmployeeDetails(int emp_id, String phone);
	void deleteEmployee(int emp_id) throws SQLException;

	HrTimezone getEmployeeById(int emp_id) throws SQLException;

	void viewAllEmployees() throws SQLException;

	void logout() throws SQLException;

//	void goToMainMenu();
}
