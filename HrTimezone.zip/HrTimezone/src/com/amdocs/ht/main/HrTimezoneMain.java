
package com.amdocs.ht.main;

import com.amdocs.ht.bean.HrTimezone;
import com.amdocs.ht.operations.HrTimezoneImpl;

import java.sql.SQLException;
import java.util.InputMismatchException;
import java.util.Scanner;

public class HrTimezoneMain {
	private static final Scanner scanner = new Scanner(System.in);
	private static final HrTimezoneImpl hrTimezoneImpl = new HrTimezoneImpl();

	public static void main(String[] args) throws SQLException {
		int choice;
		do {
			displayMenu();
			choice = getUserChoice();

			switch (choice) {
			case 1:
				registerEmployee();
				break;
			case 2:
				updateEmployeeDetails();
				break;
			case 3:
				deleteEmployee();
				break;
			case 4:
				viewAllEmployees();
				break;
			case 5:
				logout();
				break;
			default:
				System.out.println("Invalid choice. Please select a valid option.");
				break;
			}
		} while (choice != 5);

		// Close resources and exit
		try {
			hrTimezoneImpl.logout();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		scanner.close();
	}

	private static void displayMenu() {
		System.out.println("\nHR Employee Management System");
		System.out.println("1. Register Employee");
		System.out.println("2. Update Employee Details");
		System.out.println("3. Delete Employee");
		System.out.println("4. View All Employees");
		System.out.println("5. Logout");
	}

	private static int getUserChoice() {
		int choice = 0;
		boolean valid = false;

		while (!valid) {
			try {
				System.out.print("Please select an option (1-5): ");
				choice = scanner.nextInt();
				valid = (choice >= 1 && choice <= 5);
				if (!valid) {
					System.out.println("Invalid option. Please select a number between 1 and 5:");
				}
			} catch (InputMismatchException e) {
				System.out.println("Invalid input. Please enter a number between 1 and 5:");
				scanner.next(); // Clear the invalid input
			}
		}
		return choice;
	}

	private static void registerEmployee() {
		try {
			System.out.print("Enter Employee ID: ");
			int empId = scanner.nextInt();
			scanner.nextLine(); // Consume newline
			
			System.out.print("Enter Department: ");
			String department = scanner.nextLine();

			System.out.print("Enter Email: ");
			String email = scanner.nextLine();

			System.out.print("Enter Phone Number: ");
			String phone = scanner.nextLine();
			scanner.nextLine(); // Consume newline

			System.out.print("Enter Gender: ");
			String gender = scanner.nextLine();

			System.out.print("Enter Location: ");
			String location = scanner.nextLine();

			HrTimezone hrTimezone = new HrTimezone(empId, department, email, phone, gender, location);
			hrTimezoneImpl.registerEmployee(hrTimezone);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	private static void updateEmployeeDetails() throws SQLException {
		System.out.print("Enter Employee ID to update: ");
		int empId = scanner.nextInt();
		scanner.nextLine(); // Consume newline

		System.out.print("Enter New Phone Number: ");
		String phone = scanner.nextLine();
		scanner.nextLine(); // Consume newline

		hrTimezoneImpl.updateEmployeeDetails(empId, phone);
	}

	private static void deleteEmployee() {
		try {
			System.out.print("Enter Employee ID to delete: ");
			int empId = scanner.nextInt();
			scanner.nextLine(); // Consume newline

			hrTimezoneImpl.deleteEmployee(empId);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	private static void viewAllEmployees() {
		try {
			hrTimezoneImpl.viewAllEmployees();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	private static void logout() {
		try {
			hrTimezoneImpl.logout();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}