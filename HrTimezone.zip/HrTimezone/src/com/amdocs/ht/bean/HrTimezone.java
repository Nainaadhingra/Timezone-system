package com.amdocs.ht.bean;

public class HrTimezone {

	private int emp_id;
	private String department;
	private String email;
	private String phone;
	private String gender;
	private String location;

	// Default constructor
	public HrTimezone() {

	}

	public HrTimezone(int emp_id,String department, String email, String phone, String gender, String location) {
		super();
		this.emp_id = emp_id;
		this.department = department;
		this.email = email;
		this.phone = phone;
		this.gender = gender;
		this.location = location;
	}

	public int getEmp_id() {
		return emp_id;
	}

	public void setEmp_id(String department) {
		this.department = department;
	}
	public String getDepartment() {
		return department;
	}

	public void setDepartment(int emp_id) {
		this.emp_id = emp_id;
	}
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	@Override
	public String toString() {
		return "HrTimezone [emp_id=" + emp_id + ", department=" + department + ", email=" + email + ", phone=" + phone + ", gender=" + gender
				+ ", location=" + location + "]";
	}

}
