package com.amdocs.ht.bean;

public class HrTimezone {

	private int emp_id;
	private String email;
	private double phone;
	private String gender;
	private String location;

	// Default constructor
	public HrTimezone() {

	}

	public HrTimezone(int emp_id, String email, double phone, String gender, String location) {
		super();
		this.emp_id = emp_id;
		this.email = email;
		this.phone = phone;
		this.gender = gender;
		this.location = location;
	}

	public int getEmp_id() {
		return emp_id;
	}

	public void setEmp_id(int emp_id) {
		this.emp_id = emp_id;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public double getPhone() {
		return phone;
	}

	public void setPhone(double phone) {
		this.phone = phone;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	@Override
	public String toString() {
		return "HrTimezone [emp_id=" + emp_id + ", email=" + email + ", phone=" + phone + ", gender=" + gender
				+ ", location=" + location + "]";
	}

}
