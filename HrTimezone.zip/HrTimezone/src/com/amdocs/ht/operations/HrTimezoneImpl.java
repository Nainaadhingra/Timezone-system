package com.amdocs.ht.operations;

import com.amdocs.ht.bean.HrTimezone;
import com.amdocs.ht.interfaces.HrTimezoneIntf;

import java.sql.*;

public class HrTimezoneImpl implements HrTimezoneIntf {
    private Connection connection;

    public HrTimezoneImpl() {
        try {
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/employee_management", "root", "root");
        } catch (SQLException e) {
            e.printStackTrace();
            System.exit(1);
        }
    }

    @Override
    public void registerEmployee(HrTimezone hrTimezone) throws SQLException {
        String sql = "INSERT INTO emp_info (emp_id, department, email, phone, gender, location) VALUES (?, ?, ?, ?, ?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, hrTimezone.getEmp_id());
            statement.setString(2, hrTimezone.getDepartment());
            statement.setString(3, hrTimezone.getEmail());
            statement.setString(4, hrTimezone.getPhone());
            statement.setString(5, hrTimezone.getGender());
            statement.setString(6, hrTimezone.getLocation());
            int rowsInserted = statement.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("HR Timezone registered successfully.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw e;
        }
    }

    @Override
    public void updateEmployeeDetails(int emp_id, String phone) {
        String sql = "UPDATE emp_info SET phone = ? WHERE emp_id = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, phone);
            statement.setInt(2, emp_id);
            int rowsUpdated = statement.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Employee details updated successfully.");
            } else {
                System.out.println("Employee with ID " + emp_id + " does not exist.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void deleteEmployee(int emp_id) throws SQLException {
        String sql = "DELETE FROM emp_info WHERE emp_id = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, emp_id);
            int rowsDeleted = statement.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println("Employee deleted successfully.");
            } else {
                System.out.println("Employee with ID " + emp_id + " does not exist.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw e;
        }
    }

    @Override
    public HrTimezone getEmployeeById(int emp_id) throws SQLException {
        String sql = "SELECT * FROM emp_info WHERE emp_id = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, emp_id);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                return new HrTimezone(
                        resultSet.getInt("emp_id"),
                        resultSet.getString("department"),
                        resultSet.getString("email"),
                        resultSet.getString("phone"),
                        resultSet.getString("gender"),
                        resultSet.getString("location")
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw e;
        }
        return null;
    }

    @Override
    public void viewAllEmployees() throws SQLException {
        String sql = "SELECT * FROM emp_info";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            ResultSet resultSet = statement.executeQuery();
            if (!resultSet.isBeforeFirst()) {
                System.out.println("No records found.");
            } else {
                System.out.println("HR Timezone Records:");
                while (resultSet.next()) {
                    int emp_id = resultSet.getInt("emp_id");
                    String email = resultSet.getString("email");
                    String department = resultSet.getString("department");
                    String phone = resultSet.getString("phone");
                    String gender = resultSet.getString("gender");
                    String location = resultSet.getString("location");
                    System.out.println("ID: " + emp_id + ", Department: " + department + ", Email: " + email + ", Phone: " + phone + ", Gender: " + gender + ", Location: " + location);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw e;
        }
    }

    @Override
    public void logout() throws SQLException {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
                System.out.println("Logged out and connection closed.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw e;
        }
    }

//    @Override
//    public void goToMainMenu() {
//        // Display the main menu options for user to select
//        System.out.println("Returning to the main menu...");
//    }
}
