package com.amdocs.lg.main;

import java.sql.SQLException;
import java.util.Scanner;

import com.amdocs.lg.operations.LoginImpl;
import com.amdocs.lg.bean.*;;

public class Main {
	public static void main(String[] args) throws SQLException {
		Scanner scanner = new Scanner(System.in);
		LoginImpl lo = new LoginImpl();

		System.out.print("Enter employee id: ");
		String emp_id = scanner.nextLine();

		System.out.print("Enter password: ");
		String password = scanner.nextLine();

		Login login = new Login(emp_id, password);

		if (lo.verify(login)) {
			System.out.println("Login successful! Welcome ");
		} else {
			System.out.println("Login failed. Invalid username or password.");
		}

		scanner.close();
	}
}
