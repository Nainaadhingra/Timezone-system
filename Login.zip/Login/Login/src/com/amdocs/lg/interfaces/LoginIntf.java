package com.amdocs.lg.interfaces;

import java.sql.SQLException;

import com.amdocs.lg.bean.*;

public interface LoginIntf {
	boolean verify(Login login) throws SQLException;

}
