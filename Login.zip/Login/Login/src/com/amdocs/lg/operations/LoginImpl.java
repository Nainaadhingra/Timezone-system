package com.amdocs.lg.operations;

import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.amdocs.lg.interfaces.LoginIntf;
import com.amdocs.lg.bean.*;


public class LoginImpl implements LoginIntf {
	private Connection connection;
	public LoginImpl() {
		try {
			connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/employee_management", "root", "root");
		} catch (SQLException e) {
			e.printStackTrace();
			System.exit(1);
		}
	}

	@Override
	public boolean verify(Login login) throws SQLException {
		String sql = "SELECT * FROM emp_credentials WHERE emp_id = ? AND password = ?";
		try (PreparedStatement statement = connection.prepareStatement(sql)) {

			statement.setString(1, login.getEmp_id());
			statement.setString(2, login.getPassword());

			ResultSet resultSet = statement.executeQuery();
			return resultSet.next();

		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}
}
