package com.amdocs.lg.interfaces;

import com.amdocs.lg.bean.Login;

public interface LoginIntf {
	boolean verify(Login login);

}
