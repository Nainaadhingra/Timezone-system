package com.amdocs.lg.main;

import java.util.Scanner;

import com.amdocs.lg.bean.Login;
import com.amdocs.lg.interfaces.LoginIntf;
import com.amdocs.lg.operations.LoginImpl;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        LoginIntf lo = new LoginImpl();

        System.out.print("Enter employee id: ");
        String emp_id = scanner.nextLine();

        System.out.print("Enter password: ");
        String password = scanner.nextLine();

        Login login = new Login(emp_id, password);

        if (lo.verify(login)) {
            System.out.println("Login successful! Welcome " + login.getEmp_id());
        } else {
            System.out.println("Login failed. Invalid username or password.");
        }

        scanner.close();
    }
}
