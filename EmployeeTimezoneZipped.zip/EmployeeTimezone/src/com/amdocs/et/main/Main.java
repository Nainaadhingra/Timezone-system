package com.amdocs.et.main;

import java.util.Scanner;

import com.amdocs.et.bean.EmployeeTimezone;
import com.amdocs.et.operations.EmployeeTimezoneImpl;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int loginTime;
		int logoutTime;
		int leavesTotal = 3;
		int leavesApplied;
		int result;
		int choice = 0;
		int repeat = 1;

		Scanner scanner = new Scanner(System.in);

		while (repeat == 1) {

			System.out.println("1. Update Timezone ");
			System.out.println("2. Update Leaves ");
			System.out.println("3. Exit ");

			System.out.println("Enter your choice (1-4) : ");
			choice = scanner.nextInt();

			switch (choice) {
			case 1: {
				System.out.println("Enter login time: ");
				System.out.println("Enter logout time: ");
				loginTime = scanner.nextInt();
				logoutTime = scanner.nextInt();
				EmployeeTimezone employeeTime = new EmployeeTimezone(loginTime, logoutTime, 3, 0);
				EmployeeTimezoneImpl employeeTimezoneImpl = new EmployeeTimezoneImpl();
				result = employeeTimezoneImpl.workingHours(employeeTime);
				System.out.println("Total hours worked = " + result);
				break;
			}
			case 2: {
				System.out.println("Enter leaves applied: ");
				leavesApplied = scanner.nextInt();
				EmployeeTimezone employeeTime = new EmployeeTimezone(0, 0, 3, leavesApplied);
				EmployeeTimezoneImpl employeeTimezoneImpl = new EmployeeTimezoneImpl();
				result = employeeTimezoneImpl.totalLeaves(employeeTime);
				System.out.println("Leaves pending = " + result);
				break;
			}
			case 3: {
				System.exit(0);
			}
			default: {
				System.out.println("Out of range, Try again !!! ");
			}
			}

			System.out.println("\n Do you want to continue (0/1)");
			repeat = scanner.nextInt();
		}

	}

}
