package com.amdocs.et.operations;

import com.amdocs.et.bean.EmployeeTimezone;
import com.amdocs.et.interfaces.EmployeeTimezoneIntf;

public class EmployeeTimezoneImpl implements EmployeeTimezoneIntf{
	int loginTime;
	int logoutTime;
	int leavesTotal;
	int leavesApplied;
	
	@Override
	public int workingHours(EmployeeTimezone employeeTimezone) {
		// TODO Auto-generated method stub
		loginTime = employeeTimezone.getLoginTime();
		logoutTime = employeeTimezone.getLogoutTime();
		return logoutTime - loginTime;
	}

	@Override
	public int totalLeaves(EmployeeTimezone employeeTimezone) {
		// TODO Auto-generated method stub
		leavesTotal = employeeTimezone.getLeavesTotal();
		leavesApplied = employeeTimezone.getLeavesApplied();
		return leavesTotal - leavesApplied;
	}

}
