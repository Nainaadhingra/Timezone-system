package com.amdocs.et.interfaces;

import com.amdocs.et.bean.EmployeeTimezone;

public interface EmployeeTimezoneIntf {
	int workingHours(EmployeeTimezone employeeTimezone);
	int totalLeaves (EmployeeTimezone employeeTimezone);
}
