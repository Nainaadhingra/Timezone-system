package com.amdocs.et.bean;

public class EmployeeTimezone {
	private int loginTime;
	private int logoutTime;
	private int leavesTotal;
	private int leavesApplied;
	
	public EmployeeTimezone() {
		super();
	}
	public EmployeeTimezone(int loginTime, int logoutTime, int leavesTotal, int leavesApplied) {
		super();
		this.loginTime = loginTime;
		this.logoutTime = logoutTime;
		this.leavesTotal = leavesTotal;
		this.leavesApplied = leavesApplied;
	}
	public int getLoginTime() {
		return loginTime;
	}
	public void setLoginTime(int loginTime) {
		this.loginTime = loginTime;
	}
	public int getLogoutTime() {
		return logoutTime;
	}
	public void setLogoutTime(int logoutTime) {
		this.logoutTime = logoutTime;
	}
	public int getLeavesTotal() {
		return leavesTotal;
	}
	public void setLeavesTotal(int leavesTotal) {
		this.leavesTotal = leavesTotal;
	}
	public int getLeavesApplied() {
		return leavesApplied;
	}
	public void setLeavesApplied(int leavesApplied) {
		this.leavesApplied = leavesApplied;
	}
	@Override
	public String toString() {
		return "EmployeeTimezone [loginTime=" + loginTime + ", logoutTime=" + logoutTime + ", leavesTotal="
				+ leavesTotal + ", leavesApplied=" + leavesApplied + "]";
	}
}
