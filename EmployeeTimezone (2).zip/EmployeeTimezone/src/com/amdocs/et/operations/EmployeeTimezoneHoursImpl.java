package com.amdocs.et.operations;

import java.time.Duration;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

import com.amdocs.et.bean.EmployeeTimezoneHours;
import com.amdocs.et.interfaces.EmployeeTimezoneHoursIntf;

public class EmployeeTimezoneHoursImpl implements EmployeeTimezoneHoursIntf {

	@Override
	public LocalTime convertTo24HourFormat(String timeString) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm");
		try {
			return LocalTime.parse(timeString, formatter);
		} catch (DateTimeParseException e) {
			System.out.println("Invalid time format. Please use HH:mm format.");
			return null;
		}
	}

	@Override
	public long calculateTotalHoursWorked(EmployeeTimezoneHours employeeTimezoneHours) {

		LocalTime punch_in = convertTo24HourFormat(employeeTimezoneHours.getPunch_in());
		LocalTime punch_out = convertTo24HourFormat(employeeTimezoneHours.getPunch_out());

		if (punch_in != null && punch_out != null) {
			Duration duration = Duration.between(punch_in, punch_out);
			return duration.toHours(); 
		} else {
			return 0;
		}
	}
}
