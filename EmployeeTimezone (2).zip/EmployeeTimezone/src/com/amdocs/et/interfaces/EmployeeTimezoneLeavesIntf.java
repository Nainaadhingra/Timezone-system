package com.amdocs.et.interfaces;

public interface EmployeeTimezoneLeavesIntf {
	int totalLeaves(int leave_taken);
}
